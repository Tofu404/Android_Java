
Android FingerprintDialog Sample
================================

This repo has been migrated to [github.com/android/security][1]. Please check that repo for future updates. Thank you!

[1]: https://github.com/android/security


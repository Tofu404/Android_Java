package com.example.dagger.dagger2demo.model;

import android.content.Context;

public interface ICommonView
{
     Context getContext();
}

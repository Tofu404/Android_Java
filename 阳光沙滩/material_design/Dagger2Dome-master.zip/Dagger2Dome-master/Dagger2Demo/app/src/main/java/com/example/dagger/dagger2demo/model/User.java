package com.example.dagger.dagger2demo.model;

import java.io.Serializable;

public class User implements Serializable
{
    private int id;
    private String userName;
    private String pwd;

}

# 扫码下载最新demo第一时间体验新功能
## 如有问题可以加群讨论
<a target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=33dacdd367ca0b5a9ba96a196a6658666b442b3ec528850e377d50f3d607f26b"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="STV&amp;RxHttp交流群" title="STV&amp;RxHttp交流群"></a>

或者手动加QQ群：688433795

## Demo示例下载
![demo下载](https://github.com/lygttpod/AndroidCustomView/blob/master/app/src/main/res/mipmap-xxhdpi/app_download.png?raw=true)

# [**炫酷的提交按钮**](https://github.com/lygttpod/AndroidCustomView/blob/master/animation_button.md)
![99.gif](http://upload-images.jianshu.io/upload_images/2057501-0d1119721429bf71.gif?imageMogr2/auto-orient/strip)


# [**仿微信支付宝等风格的支付密码输入框的实现**](https://github.com/lygttpod/AndroidCustomView/blob/master/pay_psd_input_view.md)
![两种样式供你选择](http://upload-images.jianshu.io/upload_images/2057501-3ca764c315dcdea2.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/320)

# [**炫酷的进度条**](https://github.com/lygttpod/AndroidCustomView/blob/master/progress.md)
![progress.gif](http://upload-images.jianshu.io/upload_images/2057501-615ad5fe97faf782.gif?imageMogr2/auto-orient/strip)

# [**TextView实现打印机逐个显示的效果**](http://www.jianshu.com/p/4d987769785c)
![FadeInTextView.gif](http://upload-images.jianshu.io/upload_images/2057501-a7a751b456b25494.gif?imageMogr2/auto-orient/strip)

# [**水波动画效果多种实现方式详解**](http://www.jianshu.com/p/0cd1c1d47f4a)
![wave.gif](http://upload-images.jianshu.io/upload_images/2057501-43358432099e1e71.gif?imageMogr2/auto-orient/strip)

# [**仿QQ未读消息拖拽效果详解**](http://www.jianshu.com/p/ed2721286778)
![拖拽粘性小球.gif](http://upload-images.jianshu.io/upload_images/2057501-7df462b80a11f7e2.gif?imageMogr2/auto-orient/strip)

# [**炫酷的欢迎页**]
![欢迎页.gif](http://osnoex6vf.bkt.clouddn.com/welcome.gif)

# [**进度条**]
![进度条.gif](http://osnoex6vf.bkt.clouddn.com/loading.gif)

# [**一行代码实现吸顶悬停效果**]
![吸顶悬停.gif](http://osnoex6vf.bkt.clouddn.com/hover_view.gif)


# [**支付宝首页效果**]
![支付宝首页效果.gif](http://osnoex6vf.bkt.clouddn.com/alipay_home.gif)

